
#ifndef C_SUM_H
#define C_SUM_H

extern int sum_abs(int *, int);

#endif
