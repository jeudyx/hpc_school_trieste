
#ifndef C_SUM_H
#define C_SUM_H

int sum_abs(const int * const in, const int num);

#endif
