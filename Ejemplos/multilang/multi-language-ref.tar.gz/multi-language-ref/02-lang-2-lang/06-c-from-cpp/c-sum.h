
#ifndef C_SUM_H
#define C_SUM_H

#ifdef __cplusplus
extern "C" {
#endif

int sum_abs(int *, int);

#ifdef __cplusplus
}
#endif

#endif
